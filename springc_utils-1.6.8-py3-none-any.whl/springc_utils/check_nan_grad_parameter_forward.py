import torch
import logging


def log_nan_grad(model):
    for name, p in model.named_parameters():
        if p.grad is not None:
            if torch.isnan(p.grad).any() or torch.isinf(p.grad).any():
                logging.info(f"NaN or Inf detected in gradients for {name}")
                p.grad.zero_()
            else:
                pass
                # logging.info(f"Parameter {name} does not have gradients.")
        else:
            pass
            # logging.info(f"Parameter {name} gradients correct.")

def log_nan_parameter(model):
    for name, param in model.named_parameters():
        if torch.isnan(param).any():
            logging.info(f"NaN detected in parameter: {name}")
    
def log_nan_forward_output(outputs):
    for i, tensor in enumerate(outputs):
        if torch.isnan(tensor).any():
            nan_indices = torch.nonzero(torch.isnan(tensor))
            logging.info(f"前向过程结果出现nan, NaN detected in output[{i}] at indices: {nan_indices}")


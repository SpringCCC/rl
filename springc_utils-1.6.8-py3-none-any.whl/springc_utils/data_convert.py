import torch
import numpy as np
from PIL import Image

def toTensor(a, device=None):
    if isinstance(a, torch.Tensor):
        pass
    else:
        a = torch.from_numpy(toNumpy(a))
    return a if device is None else a.to(device)

def toNumpy(a):
    if isinstance(a, torch.Tensor):
        return a.detach().cpu().numpy()
    elif isinstance(a, np.ndarray):
        return a
    else:
        return np.asarray(a)

def toPil(a):
    if isinstance(a, np.ndarray):
        a = Image.fromarray(a)
    elif isinstance(a, torch.Tensor):
        a = Image.fromarray(toNumpy(a))
    return a

def bbox1_bbox2_ious(box1, box2):
    # bbox1: M, 4
    # bbox2: N, 4
    box1, box2 = toTensor(box1), toTensor(box2)
    bbox1 = box1[:,None] #M, 1, 4
    bbox2 = box2[None] #1, N, 4
    tl = torch.maximum(bbox1[:, :, :2], bbox2[:, :, :2])
    br = torch.minimum(bbox1[:, :, 2:], bbox2[:, :, 2:])
    inter = torch.prod(br-tl, dim=-1) * torch.all(br>tl, dim=-1)
    area1 = torch.prod(box1[:, 2:] - box1[:, :2], dim=-1)
    area2 = torch.prod(box2[:, 2:] - box2[:, :2], dim=-1)
    iou = inter / (area1[:,None] + area2[None] - inter)
    return iou
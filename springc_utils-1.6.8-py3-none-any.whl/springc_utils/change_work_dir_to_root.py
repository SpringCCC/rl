import sys
import os


def change_workdir(workdir):
    sys.path.insert(0, workdir)
    os.chdir(workdir)